Please refer to the documentation at

  http://emptyhammock.com/projects/httpd/diag/diagmod.html

Thanks!
