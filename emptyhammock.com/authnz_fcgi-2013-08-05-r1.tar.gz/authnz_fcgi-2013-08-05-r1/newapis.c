/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "newapis.h"

#include "apr_lib.h"
#include "apr_strings.h"

#include "http_log.h"

/* already called in the knowledge that the characters are hex digits */
AP_DECLARE(int) ap_hex2c(const char *x)
{
    int i;

#if !APR_CHARSET_EBCDIC
    int ch = x[0];

    if (apr_isdigit(ch)) {
        i = ch - '0';
    }
    else if (apr_isupper(ch)) {
        i = ch - ('A' - 10);
    }
    else {
        i = ch - ('a' - 10);
    }
    i <<= 4;

    ch = x[1];
    if (apr_isdigit(ch)) {
        i += ch - '0';
    }
    else if (apr_isupper(ch)) {
        i += ch - ('A' - 10);
    }
    else {
        i += ch - ('a' - 10);
    }
    return i;
#else /*APR_CHARSET_EBCDIC*/
    /*
     * we assume that the hex value refers to an ASCII character
     * so convert to EBCDIC so that it makes sense locally;
     *
     * example:
     *
     * client specifies %20 in URL to refer to a space char;
     * at this point we're called with EBCDIC "20"; after turning
     * EBCDIC "20" into binary 0x20, we then need to assume that 0x20
     * represents an ASCII char and convert 0x20 to EBCDIC, yielding
     * 0x40
     */
    char buf[1];

    if (1 == sscanf(x, "%2x", &i)) {
        buf[0] = i & 0xFF;
        ap_xlate_proto_from_ascii(buf, 1);
        return buf[0];
    }
    else {
        return 0;
    }
#endif /*APR_CHARSET_EBCDIC*/
}

AP_DECLARE(void) ap_c2hex(int ch, char *x)
{
#if !APR_CHARSET_EBCDIC
    int i;

    x[0] = '%';
    i = (ch & 0xF0) >> 4;
    if (i >= 10) {
        x[1] = ('A' - 10) + i;
    }
    else {
        x[1] = '0' + i;
    }

    i = ch & 0x0F;
    if (i >= 10) {
        x[2] = ('A' - 10) + i;
    }
    else {
        x[2] = '0' + i;
    }
#else /*APR_CHARSET_EBCDIC*/
    static const char ntoa[] = { "0123456789ABCDEF" };
    char buf[1];

    ch &= 0xFF;

    buf[0] = ch;
    ap_xlate_proto_to_ascii(buf, 1);

    x[0] = '%';
    x[1] = ntoa[(buf[0] >> 4) & 0x0F];
    x[2] = ntoa[buf[0] & 0x0F];
    x[3] = '\0';
#endif /*APR_CHARSET_EBCDIC*/
}

/*
 * canonicalise a URL-encoded string
 */

/*
 * Convert a URL-encoded string to canonical form.
 * It decodes characters which need not be encoded,
 * and encodes those which must be encoded, and does not touch
 * those which must not be touched.
 */
AP_DECLARE(char *)ap_canonenc(apr_pool_t *p, const char *x, int len,
                              enum enctype t, int forcedec,
                              int proxyreq)
{
    int i, j, ch;
    char *y;
    char *allowed;  /* characters which should not be encoded */
    char *reserved; /* characters which much not be en/de-coded */

/*
 * N.B. in addition to :@&=, this allows ';' in an http path
 * and '?' in an ftp path -- this may be revised
 *
 * Also, it makes a '+' character in a search string reserved, as
 * it may be form-encoded. (Although RFC 1738 doesn't allow this -
 * it only permits ; / ? : @ = & as reserved chars.)
 */
    if (t == enc_path) {
        allowed = "~$-_.+!*'(),;:@&=";
    }
    else if (t == enc_search) {
        allowed = "$-_.!*'(),;:@&=";
    }
    else if (t == enc_user) {
        allowed = "$-_.+!*'(),;@&=";
    }
    else if (t == enc_fpath) {
        allowed = "$-_.+!*'(),?:@&=";
    }
    else {            /* if (t == enc_parm) */
        allowed = "$-_.+!*'(),?/:@&=";
    }

    if (t == enc_path) {
        reserved = "/";
    }
    else if (t == enc_search) {
        reserved = "+";
    }
    else {
        reserved = "";
    }

    y = apr_palloc(p, 3 * len + 1);

    for (i = 0, j = 0; i < len; i++, j++) {
/* always handle '/' first */
        ch = x[i];
        if (strchr(reserved, ch)) {
            y[j] = ch;
            continue;
        }
/*
 * decode it if not already done. do not decode reverse proxied URLs
 * unless specifically forced
 */
        if ((forcedec || (proxyreq && proxyreq != PROXYREQ_REVERSE)) && ch == '%') {
            if (!apr_isxdigit(x[i + 1]) || !apr_isxdigit(x[i + 2])) {
                return NULL;
            }
            ch = ap_hex2c(&x[i + 1]);
            i += 2;
            if (ch != 0 && strchr(reserved, ch)) {  /* keep it encoded */
                ap_c2hex(ch, &y[j]);
                j += 2;
                continue;
            }
        }
/* recode it, if necessary */
        if (!apr_isalnum(ch) && !strchr(allowed, ch)) {
            ap_c2hex(ch, &y[j]);
            j += 2;
        }
        else {
            y[j] = ch;
        }
    }
    y[j] = '\0';
    return y;
}

/*
 * Parses network-location.
 *    urlp           on input the URL; on output the path, after the leading /
 *    user           NULL if no user/password permitted
 *    password       holder for password
 *    host           holder for host
 *    port           port number; only set if one is supplied.
 *
 * Returns an error string.
 */
AP_DECLARE(char *) ap_canon_netloc(apr_pool_t *p, char **const urlp, 
                                   char **userp, char **passwordp, 
                                   char **hostp, apr_port_t *port)
{
    char *addr, *scope_id, *strp, *host, *url = *urlp;
    char *user = NULL, *password = NULL;
    apr_port_t tmp_port;
    apr_status_t rv;

    if (url[0] != '/' || url[1] != '/') {
        return "Malformed URL";
    }
    host = url + 2;
    url = strchr(host, '/');
    if (url == NULL) {
        url = "";
    }
    else {
        *(url++) = '\0';    /* skip separating '/' */
    }

    /* find _last_ '@' since it might occur in user/password part */
    strp = strrchr(host, '@');

    if (strp != NULL) {
        *strp = '\0';
        user = host;
        host = strp + 1;

/* find password */
        strp = strchr(user, ':');
        if (strp != NULL) {
            *strp = '\0';
            password = ap_canonenc(p, strp + 1, strlen(strp + 1), enc_user, 1, 0);
            if (password == NULL) {
                return "Bad %-escape in URL (password)";
            }
        }

        user = ap_canonenc(p, user, strlen(user), enc_user, 1, 0);
        if (user == NULL) {
            return "Bad %-escape in URL (username)";
        }
    }
    if (userp != NULL) {
        *userp = user;
    }
    if (passwordp != NULL) {
        *passwordp = password;
    }

    /*
     * Parse the host string to separate host portion from optional port.
     * Perform range checking on port.
     */
    rv = apr_parse_addr_port(&addr, &scope_id, &tmp_port, host, p);
    if (rv != APR_SUCCESS || addr == NULL || scope_id != NULL) {
        return "Invalid host/port";
    }
    if (tmp_port != 0) { /* only update caller's port if port was specified */
        *port = tmp_port;
    }

    ap_str_tolower(addr); /* DNS names are case-insensitive */

    *urlp = url;
    *hostp = addr;

    return NULL;
}

/*
 * The below 3 functions serve to map the FCGI structs
 * back and forth between an 8 byte array. We do this to avoid
 * any potential padding issues when we send or read these
 * structures.
 *
 * NOTE: These have specific internal knowledge of the
 *       layout of the fcgi_header and fcgi_begin_request_body
 *       structs!
 */
AP_DECLARE(void) ap_fcgi_header_to_array(ap_fcgi_header *h,
                                         unsigned char a[])
{
    a[AP_FCGI_HDR_VERSION_OFFSET]        = h->version;
    a[AP_FCGI_HDR_TYPE_OFFSET]           = h->type;
    a[AP_FCGI_HDR_REQUEST_ID_B1_OFFSET]  = h->requestIdB1;
    a[AP_FCGI_HDR_REQUEST_ID_B0_OFFSET]  = h->requestIdB0;
    a[AP_FCGI_HDR_CONTENT_LEN_B1_OFFSET] = h->contentLengthB1;
    a[AP_FCGI_HDR_CONTENT_LEN_B0_OFFSET] = h->contentLengthB0;
    a[AP_FCGI_HDR_PADDING_LEN_OFFSET]    = h->paddingLength;
    a[AP_FCGI_HDR_RESERVED_OFFSET]       = h->reserved;
}

AP_DECLARE(void) ap_fcgi_header_from_array(ap_fcgi_header *h,
                                           unsigned char a[])
{
    h->version         = a[AP_FCGI_HDR_VERSION_OFFSET];
    h->type            = a[AP_FCGI_HDR_TYPE_OFFSET];
    h->requestIdB1     = a[AP_FCGI_HDR_REQUEST_ID_B1_OFFSET];
    h->requestIdB0     = a[AP_FCGI_HDR_REQUEST_ID_B0_OFFSET];
    h->contentLengthB1 = a[AP_FCGI_HDR_CONTENT_LEN_B1_OFFSET];
    h->contentLengthB0 = a[AP_FCGI_HDR_CONTENT_LEN_B0_OFFSET];
    h->paddingLength   = a[AP_FCGI_HDR_PADDING_LEN_OFFSET];
    h->reserved        = a[AP_FCGI_HDR_RESERVED_OFFSET];
}

AP_DECLARE(void) ap_fcgi_begin_request_body_to_array(ap_fcgi_begin_request_body *h,
                                                     unsigned char a[])
{
    a[AP_FCGI_BRB_ROLEB1_OFFSET]    = h->roleB1;
    a[AP_FCGI_BRB_ROLEB0_OFFSET]    = h->roleB0;
    a[AP_FCGI_BRB_FLAGS_OFFSET]     = h->flags;
    a[AP_FCGI_BRB_RESERVED0_OFFSET] = h->reserved[0];
    a[AP_FCGI_BRB_RESERVED1_OFFSET] = h->reserved[1];
    a[AP_FCGI_BRB_RESERVED2_OFFSET] = h->reserved[2];
    a[AP_FCGI_BRB_RESERVED3_OFFSET] = h->reserved[3];
    a[AP_FCGI_BRB_RESERVED4_OFFSET] = h->reserved[4];
}

AP_DECLARE(void) ap_fcgi_fill_in_header(ap_fcgi_header *header,
                                        unsigned char type,
                                        apr_uint16_t request_id,
                                        apr_uint16_t content_len,
                                        unsigned char padding_len)
{
    header->version = AP_FCGI_VERSION;

    header->type = type;

    header->requestIdB1 = ((request_id >> 8) & 0xff);
    header->requestIdB0 = ((request_id) & 0xff);

    header->contentLengthB1 = ((content_len >> 8) & 0xff);
    header->contentLengthB0 = ((content_len) & 0xff);

    header->paddingLength = padding_len;

    header->reserved = 0;
}

#define BYTES_LOGGED_PER_LINE 16
#define LOG_BYTES_BUFFER_SIZE (BYTES_LOGGED_PER_LINE * 3 + 2)

static void fmt_data(unsigned char *buf, const char *data, apr_size_t len, apr_size_t *off)
{
    unsigned char *chars;
    unsigned char *hex;
    apr_size_t this_time = 0;

    memset(buf, ' ', LOG_BYTES_BUFFER_SIZE - 1);
    buf[LOG_BYTES_BUFFER_SIZE - 1] = '\0';
    
    chars = buf; /* start character dump here */
    hex   = buf + BYTES_LOGGED_PER_LINE + 1; /* start hex dump here */
    while (*off < len && this_time < BYTES_LOGGED_PER_LINE) {
        unsigned char c = data[*off];

        if (apr_isprint(c)) {
            *chars = c;
        }
        else {
            *chars = '.';
        }

        if ((c >> 4) >= 10) {
            *hex = 'a' + ((c >> 4) - 10);
        }
        else {
            *hex = '0' + (c >> 4);
        }

        if ((c & 0x0F) >= 10) {
            *(hex + 1) = 'a' + ((c & 0x0F) - 10);
        }
        else {
            *(hex + 1) = '0' + (c & 0x0F);
        }

        chars += 1;
        hex += 2;
        *off += 1;
        ++this_time;
    }
}

AP_DECLARE(void) ap_log_data(const char *file, int line, int module_index,
                             int level, const server_rec *s, const char *label,
                             const char *data, apr_size_t len, unsigned int flags)
{
    unsigned char buf[LOG_BYTES_BUFFER_SIZE];
    apr_size_t off;
    char prefix[20];

    if (!APLOG_MODULE_IS_LEVEL(s, module_index, level)) {
        return;
    }

    if (!(flags & AP_LOG_DATA_SHOW_OFFSET)) {
        prefix[0] = '\0';
    }

    if (label) {
        ap_log_error_(file, line, module_index, level, APR_SUCCESS, s,
                      "%s (%" APR_SIZE_T_FMT " bytes)",
                      label, len);
    }

    off = 0;
    while (off < len) {
        if (flags & AP_LOG_DATA_SHOW_OFFSET) {
            apr_snprintf(prefix, sizeof prefix, "%08x: ", (unsigned int)off);
        }
        fmt_data(buf, data, len, &off);
        ap_log_error_(file, line, module_index, level, APR_SUCCESS, s,
                      "%s%s", prefix, buf);
    }
}

AP_DECLARE(void) ap_log_rdata(const char *file, int line, int module_index,
                              int level, const request_rec *r, const char *label,
                              const char *data, apr_size_t len, unsigned int flags)
{
    unsigned char buf[LOG_BYTES_BUFFER_SIZE];
    apr_size_t off;
    char prefix[20];

    if (!APLOG_R_MODULE_IS_LEVEL(r, module_index, level)) {
        return;
    }

    if (!(flags & AP_LOG_DATA_SHOW_OFFSET)) {
        prefix[0] = '\0';
    }

    if (label) {
        ap_log_rerror_(file, line, module_index, level, APR_SUCCESS, r,
                       "%s (%" APR_SIZE_T_FMT " bytes)",
                       label, len);
    }

    off = 0;
    while (off < len) {
        if (flags & AP_LOG_DATA_SHOW_OFFSET) {
            apr_snprintf(prefix, sizeof prefix, "%08x: ", (unsigned int)off);
        }
        fmt_data(buf, data, len, &off);
        ap_log_rerror_(file, line, module_index, level, APR_SUCCESS, r,
                       "%s%s", prefix, buf);
    }
}

AP_DECLARE(void) ap_log_cdata(const char *file, int line, int module_index,
                              int level, const conn_rec *c, const char *label,
                              const char *data, apr_size_t len, unsigned int flags)
{
    unsigned char buf[LOG_BYTES_BUFFER_SIZE];
    apr_size_t off;
    char prefix[20];

    if (!APLOG_C_MODULE_IS_LEVEL(c, module_index, level)) {
        return;
    }

    if (!(flags & AP_LOG_DATA_SHOW_OFFSET)) {
        prefix[0] = '\0';
    }

    if (label) {
        ap_log_cerror_(file, line, module_index, level, APR_SUCCESS, c,
                       "%s (%" APR_SIZE_T_FMT " bytes)",
                       label, len);
    }

    off = 0;
    while (off < len) {
        if (flags & AP_LOG_DATA_SHOW_OFFSET) {
            apr_snprintf(prefix, sizeof prefix, "%08x: ", (unsigned int)off);
        }
        fmt_data(buf, data, len, &off);
        ap_log_cerror_(file, line, module_index, level, APR_SUCCESS, c,
                       "%s%s", prefix, buf);
    }
}

AP_DECLARE(apr_status_t) ap_connect_to_backend(apr_socket_t **newsock,
                                               request_rec *r,
                                               int module_index,
                                               apr_sockaddr_t *backend_addrs,
                                               const char *backend_name)
{
#define FN_LOG_MARK __FILE__,__LINE__,module_index
    apr_status_t rv = APR_EINVAL; /* returned if no backend addr was provided */
    int connected = 0;
    apr_sockaddr_t *addr = backend_addrs;

    while (addr && !connected) {
        int loglevel = addr->next ? APLOG_DEBUG : APLOG_ERR;
        rv = apr_socket_create(newsock, addr->family,
                               SOCK_STREAM, 0, r->pool);
        if (rv != APR_SUCCESS) {
            ap_log_rerror(FN_LOG_MARK, loglevel, rv, r,
                          APLOGNO() "error creating family %d socket for "
                          "target %s",
                          addr->family, backend_name);
            addr = addr->next;
            continue;
        }

        apr_socket_opt_set(*newsock, APR_TCP_NODELAY, 1);
        apr_socket_timeout_set(*newsock, r->server->timeout);

        rv = apr_socket_connect(*newsock, addr);
        if (rv != APR_SUCCESS) {
            apr_socket_close(*newsock);
            ap_log_rerror(FN_LOG_MARK, loglevel, rv, r,
                          APLOGNO() "attempt to connect to %pI (%s) failed",
                          addr, backend_name);
            addr = addr->next;
            continue;
        }

        connected = 1;
    }

    return rv;
#undef FN_LOG_MARK
}
