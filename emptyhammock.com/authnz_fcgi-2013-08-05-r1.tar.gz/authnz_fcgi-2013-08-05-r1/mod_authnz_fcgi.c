/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "apr_hash.h"
#include "apr_lib.h"
#include "apr_strings.h"

#include "ap_provider.h"
#include "httpd.h"
#include "http_config.h"
#include "http_request.h"
#include "http_log.h"
#include "util_script.h"
#include "ap_provider.h"
#include "mod_auth.h"

#include "newapis.h"

module AP_MODULE_DECLARE_DATA authnz_fcgi_module;

typedef struct {
    const char *name; /* provider name */
    const char *backend; /* backend address, as configured */
    const char *host;
    apr_port_t port;
    apr_sockaddr_t *backend_addrs;
    int is_authn;
    int is_authz;
} fcgi_provider_conf;

typedef struct {
    /* If an "authnz" provider successfully authenticates, record
     * the provider name here for checking during authz.
     */
    const char *successful_authnz_provider;
} fcgi_request_conf;

static apr_hash_t *fcgi_authn_providers, *fcgi_authz_providers;

static void log_provider_info(const fcgi_provider_conf *conf, request_rec *r)
{
    ap_log_rerror(APLOG_MARK, APLOG_DEBUG, 0, r,
                  APLOGNO() "name %s, backend %s, host %s, port %d, first address %pI",
                  conf->name,
                  conf->backend,
                  conf->host,
                  (int)conf->port,
                  conf->backend_addrs);
}

static void setupenv(request_rec *r, const char *password, const char *apache_role)
{
    ap_add_common_vars(r);
    ap_add_cgi_vars(r);
    apr_table_setn(r->subprocess_env, "FCGI_ROLE", AP_FCGI_AUTHORIZER_STR);
    if (apache_role) {
        apr_table_setn(r->subprocess_env, "FCGI_APACHE_ROLE", apache_role);
    }
    if (password) {
        apr_table_setn(r->subprocess_env, "REMOTE_PASSWD", password);
    }
    /* Drop the variables CONTENT_LENGTH, PATH_INFO, PATH_TRANSLATED,
     * SCRIPT_NAME and most Hop-By-Hop headers - EXCEPT we will pass
     * PROXY_AUTH to allow CGI to perform proxy auth for httpd
     */
    apr_table_unset(r->subprocess_env, "CONTENT_LENGTH");
    apr_table_unset(r->subprocess_env, "PATH_INFO");
    apr_table_unset(r->subprocess_env, "PATH_TRANSLATED");
    apr_table_unset(r->subprocess_env, "SCRIPT_NAME");
    apr_table_unset(r->subprocess_env, "HTTP_KEEP_ALIVE");
    apr_table_unset(r->subprocess_env, "HTTP_TE");
    apr_table_unset(r->subprocess_env, "HTTP_TRAILER");
    apr_table_unset(r->subprocess_env, "HTTP_TRANSFER_ENCODING");
    apr_table_unset(r->subprocess_env, "HTTP_UPGRADE");

    /* Connection hop-by-hop header to prevent the CGI from hanging */
    apr_table_set(r->subprocess_env, "HTTP_CONNECTION", "close");
}

static apr_status_t recv_data(const fcgi_provider_conf *conf,
                              request_rec *r,
                              apr_socket_t *s,
                              char *buf,
                              apr_size_t *buflen)
{
    apr_status_t rv;

    rv = apr_socket_recv(s, buf, buflen);
    if (rv != APR_SUCCESS) {
        ap_log_rerror(APLOG_MARK, APLOG_ERR, 0, r,
                      APLOGNO() "Couldn't read from backend %s",
                      conf->backend);
        return rv;
    }

    ap_log_rdata(APLOG_MARK, APLOG_TRACE5, r, "FastCGI data received",
                 buf, *buflen, AP_LOG_DATA_SHOW_OFFSET);
    return APR_SUCCESS;
}

static apr_status_t sendv_data(const fcgi_provider_conf *conf,
                               request_rec *r,
                               apr_socket_t *s,
                               struct iovec *vec,
                               int nvec,
                               apr_size_t *len)
{
    apr_size_t to_write = 0, written = 0;
    apr_status_t rv = APR_SUCCESS;
    int i, offset;

    for (i = 0; i < nvec; i++) {
        to_write += vec[i].iov_len;
        ap_log_rdata(APLOG_MARK, APLOG_TRACE5, r, "FastCGI data sent",
                     vec[i].iov_base, vec[i].iov_len, AP_LOG_DATA_SHOW_OFFSET);
    }

    offset = 0;
    while (to_write) {
        apr_size_t n = 0;
        rv = apr_socket_sendv(s, vec + offset, nvec - offset, &n);
        if (rv != APR_SUCCESS) {
            ap_log_rerror(APLOG_MARK, APLOG_ERR, rv, r,
                          "Sending data to %s failed",
                          conf->backend);
            break;
        }
        if (n > 0) {
            written += n;
            if (written >= to_write)
                break;                 /* short circuit out */
            for (i = offset; i < nvec; ) {
                if (n >= vec[i].iov_len) {
                    offset++;
                    n -= vec[i++].iov_len;
                } else {
                    vec[i].iov_len -= n;
                    vec[i].iov_base = (char *) vec[i].iov_base + n;
                    break;
                }
            }
        }
    }

    *len = written;

    return rv;
}

static apr_status_t send_begin_request(request_rec *r,
                                       const fcgi_provider_conf *conf,
                                       apr_socket_t *s, int role,
                                       apr_uint16_t request_id)
{
    struct iovec vec[2];
    ap_fcgi_header header;
    unsigned char farray[AP_FCGI_HEADER_LEN];
    ap_fcgi_begin_request_body brb;
    unsigned char abrb[AP_FCGI_HEADER_LEN];
    apr_size_t len;

    ap_fcgi_fill_in_header(&header, AP_FCGI_BEGIN_REQUEST, request_id, sizeof(abrb), 0);

    brb.roleB1 = ((role >> 8) & 0xff);
    brb.roleB0 = (role & 0xff);
    brb.flags = AP_FCGI_KEEP_CONN;
    brb.reserved[0] = 0;
    brb.reserved[1] = 0;
    brb.reserved[2] = 0;
    brb.reserved[3] = 0;
    brb.reserved[4] = 0;

    ap_fcgi_header_to_array(&header, farray);
    ap_fcgi_begin_request_body_to_array(&brb, abrb);

    vec[0].iov_base = (void *)farray;
    vec[0].iov_len = sizeof(farray);
    vec[1].iov_base = (void *)abrb;
    vec[1].iov_len = sizeof(abrb);

    return sendv_data(conf, r, s, vec, 2, &len);
}

static apr_status_t send_environment(apr_socket_t *s, const fcgi_provider_conf *conf,
                                     request_rec *r, apr_uint16_t request_id)
{
    const char *fn = "send_environment";
    const apr_array_header_t *envarr;
    const apr_table_entry_t *elts;
    struct iovec vec[2];
    ap_fcgi_header header;
    unsigned char farray[AP_FCGI_HEADER_LEN];
    apr_size_t bodylen, envlen;
    char *body, *itr;
    apr_status_t rv;
    apr_size_t len;
    int i, numenv;

    bodylen = envlen = 0;

    envarr = apr_table_elts(r->subprocess_env);

    elts = (const apr_table_entry_t *) envarr->elts;

    for (i = 0; i < envarr->nelts; ++i) {
        apr_size_t keylen, vallen;

        if (! elts[i].key) {
            continue;
        }

        keylen = strlen(elts[i].key);

        if (keylen >> 7 == 0) {
            envlen += 1;
        }
        else {
            envlen += 4;
        }

        envlen += keylen;

        vallen = strlen(elts[i].val);

        ap_log_rerror(APLOG_MARK, APLOG_TRACE2, 0, r,
                      APLOGNO() "%s: '%s': '%s'",
                      fn, elts[i].key, 
                      !strcmp(elts[i].key, "REMOTE_PASSWD") ? "XXXXXXXX" : elts[i].val);

        if (vallen >> 7 == 0) {
            envlen += 1;
        }
        else {
            envlen += 4;
        }

        envlen += vallen;

        /* The cast of bodylen is safe since AP_FCGI_MAX_ENV_SIZE is for sure an int */
        if (envlen > AP_FCGI_MAX_ENV_SIZE) {
            ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r,
                          APLOGNO() "%s: truncating environment to %d bytes and %d elements",
                          fn, (int)bodylen, i);
            break;
        }

        bodylen = envlen;
    }

    numenv = i;

    body = apr_pcalloc(r->pool, bodylen);

    itr = body;

    for (i = 0; i < numenv; ++i) {
        apr_size_t keylen, vallen;

        if (! elts[i].key) {
            continue;
        }

        keylen = strlen(elts[i].key);

        if (keylen >> 7 == 0) {
            itr[0] = keylen & 0xff;
            itr += 1;
        }
        else {
            itr[0] = ((keylen >> 24) & 0xff) | 0x80;
            itr[1] = ((keylen >> 16) & 0xff);
            itr[2] = ((keylen >> 8) & 0xff);
            itr[3] = ((keylen) & 0xff);
            itr += 4;
        }

        vallen = strlen(elts[i].val);

        if (vallen >> 7 == 0) {
            itr[0] = vallen & 0xff;
            itr += 1;
        }
        else {
            itr[0] = ((vallen >> 24) & 0xff) | 0x80;
            itr[1] = ((vallen >> 16) & 0xff);
            itr[2] = ((vallen >> 8) & 0xff);
            itr[3] = ((vallen) & 0xff);
            itr += 4;
        }

        memcpy(itr, elts[i].key, keylen);
        itr += keylen;

        memcpy(itr, elts[i].val, vallen);
        itr += vallen;
    }

    ap_fcgi_fill_in_header(&header, AP_FCGI_PARAMS, request_id, (apr_uint16_t)bodylen, 0);
    ap_fcgi_header_to_array(&header, farray);

    vec[0].iov_base = (void *)farray;
    vec[0].iov_len = sizeof(farray);
    vec[1].iov_base = body;
    vec[1].iov_len = bodylen;

    rv = sendv_data(conf, r, s, vec, 2, &len);
    if (rv) {
        return rv;
    }

    ap_fcgi_fill_in_header(&header, AP_FCGI_PARAMS, request_id, 0, 0);
    ap_fcgi_header_to_array(&header, farray);

    vec[0].iov_base = (void *)farray;
    vec[0].iov_len = sizeof(farray);

    return sendv_data(conf, r, s, vec, 1, &len);
}

enum {
  HDR_STATE_READING_HEADERS,
  HDR_STATE_GOT_CR,
  HDR_STATE_GOT_CRLF,
  HDR_STATE_GOT_CRLFCR,
  HDR_STATE_GOT_LF,
  HDR_STATE_DONE_WITH_HEADERS
};

/* Try to find the end of the script headers in the response from the back
 * end fastcgi server. STATE holds the current header parsing state for this
 * request.
 *
 * Returns 0 if it can't find the end of the headers, and 1 if it found the
 * end of the headers. */
static int handle_headers(request_rec *r,
                          int *state,
                          char *readbuf)
{
    const char *itr = readbuf;

    while (*itr) {
        if (*itr == '\r') {
            switch (*state) {
                case HDR_STATE_GOT_CRLF:
                    *state = HDR_STATE_GOT_CRLFCR;
                    break;

                default:
                    *state = HDR_STATE_GOT_CR;
                    break;
            }
        }
        else if (*itr == '\n') {
            switch (*state) {
                 case HDR_STATE_GOT_LF:
                     *state = HDR_STATE_DONE_WITH_HEADERS;
                     break;

                 case HDR_STATE_GOT_CR:
                     *state = HDR_STATE_GOT_CRLF;
                     break;

                 case HDR_STATE_GOT_CRLFCR:
                     *state = HDR_STATE_DONE_WITH_HEADERS;
                     break;

                 default:
                     *state = HDR_STATE_GOT_LF;
                     break;
            }
        }
        else {
            *state = HDR_STATE_READING_HEADERS;
        }

        if (*state == HDR_STATE_DONE_WITH_HEADERS)
            break;

        ++itr;
    }

    if (*state == HDR_STATE_DONE_WITH_HEADERS) {
        return 1;
    }

    return 0;
}

static apr_status_t handle_response(const fcgi_provider_conf *conf,
                                    request_rec *r, apr_socket_t *s,
                                    apr_uint16_t request_id)
{
    const char *fn = "handle_response";
    apr_bucket *b;
    apr_bucket_brigade *ob;
    int seen_end_of_headers = 0, done = 0;
    apr_status_t rv = APR_SUCCESS;
    int script_error_status = HTTP_OK;
    ap_fcgi_header header;
    unsigned char farray[AP_FCGI_HEADER_LEN];
    int header_state = HDR_STATE_READING_HEADERS;
    apr_pool_t *setaside_pool;

    apr_pool_create(&setaside_pool, r->pool);

    ob = apr_brigade_create(r->pool, r->connection->bucket_alloc);

    while (!done && rv == APR_SUCCESS) {
        char readbuf[AP_IOBUFSIZE + 1];
        apr_size_t readbuflen;
        apr_size_t clen;
        int rid, type;
        char plen;

        memset(readbuf, 0, sizeof(readbuf));
        memset(farray, 0, sizeof(farray));

        /* First, we grab the header... */
        readbuflen = AP_FCGI_HEADER_LEN;
        rv = recv_data(conf, r, s, (char *) farray, &readbuflen);
        if (rv != APR_SUCCESS) {
            break;
        }

        if (readbuflen != AP_FCGI_HEADER_LEN) {
            ap_log_rerror(APLOG_MARK, APLOG_ERR, 0, r,
                          APLOGNO() "%s: Failed to read entire header; "
                          "got %" APR_SIZE_T_FMT " wanted %d",
                          fn, readbuflen, AP_FCGI_HEADER_LEN);
            rv = APR_EINVAL;
            break;
        }

        ap_fcgi_header_from_array(&header, farray);

        if (header.version != AP_FCGI_VERSION) {
            ap_log_rerror(APLOG_MARK, APLOG_ERR, 0, r,
                          APLOGNO() "%s: Got bogus FastCGI header version %d",
                          fn, (int)header.version);
            rv = APR_EINVAL;
            break;
        }

        type = header.type;

        rid = header.requestIdB1 << 8;
        rid |= header.requestIdB0;
        
        if (rid != request_id) {
            ap_log_rerror(APLOG_MARK, APLOG_ERR, 0, r,
                          APLOGNO() "%s: Got bogus FastCGI header request id %d, expected %d",
                          fn, rid, request_id);
            rv = APR_EINVAL;
            break;
        }

        clen = header.contentLengthB1 << 8;
        clen |= header.contentLengthB0;

        plen = header.paddingLength;

recv_again:
        if (clen > sizeof(readbuf) - 1) {
            readbuflen = sizeof(readbuf) - 1;
        } else {
            readbuflen = clen;
        }

        /* Now get the actual data.  Yes it sucks to do this in a second
         * recv call, this will eventually change when we move to real
         * nonblocking recv calls. */
        if (readbuflen != 0) {
            rv = recv_data(conf, r, s, readbuf, &readbuflen);
            if (rv != APR_SUCCESS) {
                break;
            }
            readbuf[readbuflen] = 0;
        }

        switch (type) {
        case AP_FCGI_STDOUT:
            if (clen != 0) {
                b = apr_bucket_transient_create(readbuf,
                                                readbuflen,
                                                r->connection->bucket_alloc);

                APR_BRIGADE_INSERT_TAIL(ob, b);

                if (! seen_end_of_headers) {
                    int st = handle_headers(r, &header_state, readbuf);

                    if (st == 1) {
                        int status;
                        seen_end_of_headers = 1;

                        status = ap_scan_script_header_err_brigade_ex(r, ob,
                                                                      NULL, APLOG_MODULE_INDEX);
                        /* suck in all the rest */
                        if (status != OK) {
                            apr_brigade_cleanup(ob);
                            r->status = status;
                            ap_log_rerror(APLOG_MARK, APLOG_ERR, 0, r,
                                          APLOGNO() "%s: Error parsing script headers from %s",
                                          fn, conf->backend);
                            rv = APR_EINVAL;
                            break;
                        }

                        if (script_error_status == HTTP_OK) {
                            /* XXX make sure there isn't any other output */
                        }
                        apr_brigade_cleanup(ob);

                        apr_pool_clear(setaside_pool);
                    }
                    else {
                        /* We're still looking for the end of the
                         * headers, so this part of the data will need
                         * to persist. */
                        apr_bucket_setaside(b, setaside_pool);
                    }
                } else {
                    /* we've already passed along the headers, so now pass
                     * through the content.  we could simply continue to
                     * setaside the content and not pass until we see the
                     * 0 content-length (below, where we append the EOS),
                     * but that could be a huge amount of data; so we pass
                     * along smaller chunks
                     */
                    if (script_error_status == HTTP_OK) {
                        /* make sure there isn't any other output */
                    }
                    apr_brigade_cleanup(ob);
                }

                /* If we didn't read all the data go back and get the
                 * rest of it. */
                if (clen > readbuflen) {
                    clen -= readbuflen;
                    goto recv_again;
                }
            } else {
                /* XXX what if we haven't seen end of the headers yet? */

                if (script_error_status == HTTP_OK) {
                    /* XXX log warning if there is any output remaining */
                }
                
                /* XXX Why don't we cleanup here?  (logic from AJP) */
            }
            break;

        case AP_FCGI_STDERR:
            if (clen) {
                ap_log_rerror(APLOG_MARK, APLOG_WARNING, 0, r,
                              APLOGNO() "%s: Logged from %s: '%s'",
                              fn, conf->backend, readbuf);
            }

            if (clen > readbuflen) {
                clen -= readbuflen;
                goto recv_again;
            }
            break;

        case AP_FCGI_END_REQUEST:
            done = 1;
            break;

        default:
            ap_log_rerror(APLOG_MARK, APLOG_ERR, 0, r,
                          APLOGNO() "%s: Got bogus FastCGI record type %d",
                          fn, type);
            break;
        }
        
        if (plen) {
            readbuflen = plen;
            
            rv = recv_data(conf, r, s, readbuf, &readbuflen);
            if (rv != APR_SUCCESS) {
                break;
            }
        }
    }

    return rv;
}

/* almost from mod_fcgid */
static int mod_fcgid_modify_auth_header(void *vars,
                                        const char *key, const char *val)
{
    /* When the application gives a 200 response, the server ignores response
       headers whose names aren't prefixed with Variable- prefix, and ignores
       any response content */
    if (strncasecmp(key, "Variable-", 9) == 0)
        apr_table_setn(vars, key, val);
    return 1;
}

static int fix_auth_header(void *vr, const char *key, const char *val)
{
    request_rec *r = vr;

    ap_log_rerror(APLOG_MARK, APLOG_DEBUG, 0, r, "moving %s->%s", key, val);
    apr_table_unset(r->err_headers_out, key);
    apr_table_setn(r->subprocess_env, key + 9, val);
    return 1;
}

static void req_rsp(request_rec *r, const fcgi_provider_conf *conf,
                    const char *password, const char *apache_role)
{
    const char *fn = "req_rsp";
    apr_socket_t *s;
    apr_table_t *saved_subprocess_env = 
      apr_table_copy(r->pool, r->subprocess_env);
    apr_size_t len;
    struct iovec vec[2];
    ap_fcgi_header header;
    unsigned char farray[AP_FCGI_HEADER_LEN];
    apr_status_t rv;

    setupenv(r, password, apache_role);

    rv = ap_connect_to_backend(&s, r, APLOG_MODULE_INDEX, conf->backend_addrs, 
                               conf->backend);
    if (rv == APR_SUCCESS) {
        apr_uint16_t request_id = 1;

        rv = send_begin_request(r, conf, s, AP_FCGI_AUTHORIZER, request_id);
        if (rv != APR_SUCCESS) {
            ap_log_rerror(APLOG_MARK, APLOG_ERR, rv, r,
                          APLOGNO() "%s: Failed writing request to %s",
                          fn, conf->backend);
        }

        if (rv == APR_SUCCESS) {
            rv = send_environment(s, conf, r, request_id);
            if (rv != APR_SUCCESS) {
                ap_log_rerror(APLOG_MARK, APLOG_ERR, rv, r,
                              APLOGNO() "%s: Failed writing environment to %s",
                              fn, conf->backend);
            }
        }

        if (rv == APR_SUCCESS) {
            /* The responder owns the request body, not the authorizer, and we don't
             * support feeding it to the authorizer here and allowing it to be 
             * replayed to the responder later.
             */

            /* send empty FCGI_STDIN */
            ap_fcgi_fill_in_header(&header, AP_FCGI_STDIN, request_id, 0, 0);
            ap_fcgi_header_to_array(&header, farray);
            vec[0].iov_base = (void *)farray;
            vec[0].iov_len = sizeof(farray);
            rv = sendv_data(conf, r, s, vec, 1, &len);
            if (rv != APR_SUCCESS) {
                r->status = HTTP_INTERNAL_SERVER_ERROR;
                ap_log_rerror(APLOG_MARK, APLOG_ERR, rv, r,
                              APLOGNO() "%s: Failed writing empty stdin to %s",
                              fn, conf->backend);
            }
        }

        if (rv == APR_SUCCESS) {
            rv = handle_response(conf, r, s, request_id);
            if (rv != APR_SUCCESS) {
                ap_log_rerror(APLOG_MARK, APLOG_ERR, rv, r,
                              APLOGNO() "%s: Failed handling response from %s",
                              fn, conf->backend);
            }
        }

        /* NYET: process headers Variable-* */

        apr_socket_close(s);
    }

    if (rv != APR_SUCCESS) {
        /* some sort of mechanical problem */
        r->status = HTTP_INTERNAL_SERVER_ERROR;
    }

    r->subprocess_env = saved_subprocess_env;

    if (r->status == HTTP_OK) {
        /* An Authorizer application's 200 response may include headers
         * whose names are prefixed with Variable-, and they should be
         * available to subsequent phases via subprocess_env (and yanked
         * from the client response).
         */
        apr_table_t *vars = apr_table_make(r->pool, 10);
        apr_table_do(mod_fcgid_modify_auth_header, vars,
                     r->err_headers_out, NULL);
        apr_table_do(fix_auth_header, r, vars, NULL);
    }
}

static authn_status fcgi_check_password(request_rec *r, const char *user,
                                        const char *password)
{
    const char *fn = "fcgi_check_password";
    const char *prov = apr_table_get(r->notes, AUTHN_PROVIDER_NAME_NOTE);
    const fcgi_provider_conf *conf;

    ap_log_rerror(APLOG_MARK, APLOG_DEBUG, 0, r,
                  APLOGNO() "%s(%s, XXX), provider %s",
                  fn, user, prov);

    if (!prov) {
        ap_log_rerror(APLOG_MARK, APLOG_CRIT, 0, r,
                      APLOGNO() "%s: provider note isn't set", fn);
        return AUTH_GENERAL_ERROR;
    }

    conf = apr_hash_get(fcgi_authn_providers, prov, APR_HASH_KEY_STRING);
    if (!conf) {
        ap_log_rerror(APLOG_MARK, APLOG_CRIT, 0, r,
                      APLOGNO() "%s: can't find config for provider %s",
                      fn, prov);
        return AUTH_GENERAL_ERROR;
    }

    if (APLOGrdebug(r)) {
        log_provider_info(conf, r);
    }

    req_rsp(r, conf, password, AP_FCGI_APACHE_ROLE_AUTHENTICATOR_STR);

    if (r->status == HTTP_OK) {
        if (conf->is_authz) {
            /* combined authn/authz phase, so app won't be invoked for authz
             *
             * Remember that the request was successfully authorized by this
             * provider.
             */
            fcgi_request_conf *rconf = apr_palloc(r->pool, sizeof(*rconf));
            rconf->successful_authnz_provider = conf->name;
            ap_set_module_config(r->request_config, &authnz_fcgi_module, rconf);
        }
        return AUTH_GRANTED;
    }
    else if (r->status == HTTP_INTERNAL_SERVER_ERROR) {
        return AUTH_GENERAL_ERROR;
    }
    else {
        return AUTH_DENIED;
    }
}

static authn_status fcgi_get_realm_hash(request_rec *r, const char *user,
                                        const char *realm, char **rethash)
{
    const char *fn = "fcgi_get_realm_hash";
    const char *prov = apr_table_get(r->notes, AUTHN_PROVIDER_NAME_NOTE);
    const fcgi_provider_conf *conf;

    ap_log_rerror(APLOG_MARK, APLOG_DEBUG, 0, r,
                  APLOGNO() "%s(%s, %s), provider %s",
                  fn, user, realm, prov);

    if (!prov) {
        ap_log_rerror(APLOG_MARK, APLOG_CRIT, 0, r,
                      APLOGNO() "%s: provider note isn't set", fn);
        return AUTH_GENERAL_ERROR;
    }

    conf = apr_hash_get(fcgi_authn_providers, prov, APR_HASH_KEY_STRING);
    if (!conf) {
        ap_log_rerror(APLOG_MARK, APLOG_CRIT, 0, r,
                      APLOGNO() "%s: can't find config for provider %s",
                      fn, prov);
        return AUTH_GENERAL_ERROR;
    }

    if (APLOGrdebug(r)) {
        log_provider_info(conf, r);
    }

    /* I dunno when this is called! */
    return AUTH_GENERAL_ERROR;
}

static const authn_provider fcgi_authn_provider = {
    &fcgi_check_password,
    &fcgi_get_realm_hash,
};

static authz_status fcgi_authz_check(request_rec *r,
                                     const char *require_line,
                                     const void *parsed_require_line)
{
    const char *fn = "fcgi_authz_check";
    const char *prov = apr_table_get(r->notes, AUTHZ_PROVIDER_NAME_NOTE);
    const fcgi_provider_conf *conf;

    ap_log_rerror(APLOG_MARK, APLOG_DEBUG, 0, r,
                  "%s(%s)", fn, require_line);

    if (!prov) {
        ap_log_rerror(APLOG_MARK, APLOG_CRIT, 0, r,
                      APLOGNO() "%s: provider note isn't set", fn);
        return AUTHZ_GENERAL_ERROR;
    }

    conf = apr_hash_get(fcgi_authz_providers, prov, APR_HASH_KEY_STRING);
    if (!conf) {
        ap_log_rerror(APLOG_MARK, APLOG_CRIT, 0, r,
                      APLOGNO() "%s: can't find config for provider %s",
                      fn, prov);
        return AUTHZ_GENERAL_ERROR;
    }

    if (APLOGrdebug(r)) {
        log_provider_info(conf, r);
    }

    if (!r->user) {
        return AUTHZ_DENIED_NO_USER;
    }

    if (conf->is_authn) {
        /* combined authn/authz phase, so app won't be invoked for authz
         *
         * If the provider already successfully authorized this request, 
         * success.
         */
        fcgi_request_conf *rconf = ap_get_module_config(r->request_config,
                                                        &authnz_fcgi_module);
        if (rconf
            && rconf->successful_authnz_provider
            && !strcmp(rconf->successful_authnz_provider, conf->name)) {
            return AUTHZ_GRANTED;
        }
        else {
            return AUTHZ_DENIED;
        }
    }
    else {
        req_rsp(r, conf, NULL, AP_FCGI_APACHE_ROLE_AUTHORIZER_STR);

        if (r->status == HTTP_OK) {
            return AUTHZ_GRANTED;
        }
        else if (r->status == HTTP_INTERNAL_SERVER_ERROR) {
            return AUTHZ_GENERAL_ERROR;
        }
        else {
            return AUTHZ_DENIED;
        }
    }
}

static const char *fcgi_authz_parse(cmd_parms *cmd, const char *require_line,
                                    const void **parsed_require_line)
{
    /* Allowed form: Require [not] registered-provider-name<EOS>
     */
    if (strcmp(require_line, "")) {
        return "mod_authnz_fcgi doesn't support restrictions on providers "
               "(i.e., multiple require args)";
    }

    return NULL;
}

static const authz_provider fcgi_authz_provider = {
    &fcgi_authz_check,
    &fcgi_authz_parse,
};

/* AuthnzFcgiAuthProvider {authn|authz|authnz} provider-name fcgi://backendhost:backendport/
 */
static const char *fcgi_register_authn_provider(cmd_parms *cmd,
                                                void *d,
                                                int argc,
                                                char *const argv[])
{
    apr_status_t rv;
    char *backend, *host;
    const char *err, *stype;
    fcgi_provider_conf *conf = apr_pcalloc(cmd->pool, sizeof(*conf));
    int ca = 0;

    err = ap_check_cmd_context(cmd, GLOBAL_ONLY);
    if (err)
        return err;

    if (ca >= argc) {
        return "AuthnzFcgiAuthProvider: No type given";
    }

    stype = argv[ca];
    ca++;

    if (!strcasecmp(stype, "authn")) {
        conf->is_authn = 1;
    }
    else if (!strcasecmp(stype, "authz")) {
        conf->is_authz = 1;
    }
    else if (!strcasecmp(stype, "authnz")) {
        conf->is_authn = conf->is_authz = 1;
    }
    else {
        return apr_pstrcat(cmd->pool,
                           "AuthnzFcgiAuthProvider: Invalid provider type ",
                           stype,
                           NULL);
    }

    if (ca >= argc) {
        return "AuthnzFcgiAuthProvider: No provider name given";
    }
    conf->name = argv[ca];
    ca++;

    if (ca >= argc) {
        return "AuthnzFcgiAuthProvider: No backend-address given";
    }

    backend = apr_pstrdup(cmd->pool, argv[ca]);
    if (strncasecmp(backend, "fcgi:", 5)) {
        return "AuthnzFcgiAuthProvider: backend-address must start with "
               "\"fcgi:\"";
    }
    backend += 5;

    err = ap_canon_netloc(cmd->pool, &backend, NULL, NULL,
                          &host, &conf->port);
    if (err) {
        return apr_pstrcat(cmd->pool,
                           "AuthnzFcgiAuthProvider: Failed to parse ",
                           argv[ca],
                           ": ",
                           err,
                           NULL);
    }

    conf->backend = argv[ca];
    conf->host = host;
    ca++;

    rv = apr_sockaddr_info_get(&conf->backend_addrs, conf->host,
                               APR_UNSPEC, conf->port, 0, cmd->pool);
    if (rv != APR_SUCCESS) {
        ap_log_error(APLOG_MARK, APLOG_STARTUP|APLOG_CRIT, rv, NULL,
                     APLOGNO() "Address %s could not be resolved",
                     conf->backend);
        return "AuthnzFcgiAuthProvider: Error resolving backend address";
    }

    if (ca != argc) {
        return apr_pstrcat(cmd->pool,
                           "AuthnzFcgiAuthProvider: Unexpected parameter ",
                           argv[ca],
                           NULL);
    }

    if (conf->is_authn) {
        apr_hash_set(fcgi_authn_providers, conf->name, APR_HASH_KEY_STRING,
                     conf);
        ap_register_auth_provider(cmd->pool, AUTHN_PROVIDER_GROUP,
                                  conf->name,
                                  AUTHN_PROVIDER_VERSION,
                                  &fcgi_authn_provider,
                                  AP_AUTH_INTERNAL_PER_CONF);
    }

    if (conf->is_authz) {
        apr_hash_set(fcgi_authz_providers, conf->name, APR_HASH_KEY_STRING,
                     conf);
        ap_register_auth_provider(cmd->pool, AUTHZ_PROVIDER_GROUP,
                                  conf->name,
                                  AUTHZ_PROVIDER_VERSION,
                                  &fcgi_authz_provider,
                                  AP_AUTH_INTERNAL_PER_CONF);
    }

    return NULL;
}

static const command_rec fcgi_cmds[] = {
    AP_INIT_TAKE_ARGV("AuthnzFcgiAuthProvider", 
                      fcgi_register_authn_provider,
                      NULL,
                      RSRC_CONF,
                      "Define a FastCGI authn and/or authz provider"),

    {NULL}
};

static void fcgi_register_hooks(apr_pool_t *p)
{
    fcgi_authn_providers = apr_hash_make(p);
    fcgi_authz_providers = apr_hash_make(p);
}

AP_DECLARE_MODULE(authnz_fcgi) =
{
    STANDARD20_MODULE_STUFF,
    NULL,                            /* dir config creater */
    NULL,                            /* dir merger --- default is to override */
    NULL,                            /* server config */
    NULL,                            /* merge server config */
    fcgi_cmds,                       /* command apr_table_t */
    fcgi_register_hooks              /* register hooks */
};
