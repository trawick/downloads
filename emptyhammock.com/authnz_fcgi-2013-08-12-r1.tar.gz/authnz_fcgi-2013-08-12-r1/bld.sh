#!/bin/sh

APXS=${APXS:=/usr/local/bin/apxs}

# compile+link
echo $APXS -c mod_authnz_fcgi.c newapis.c
if $APXS -c mod_authnz_fcgi.c newapis.c; then
    :
else
    exit 1
fi

# install
echo ""
echo ""
echo "Run this command to install the module, as root or via sudo if necessary:"
echo ""
echo ""
echo $APXS -i mod_authnz_fcgi.la
echo ""
echo ""
